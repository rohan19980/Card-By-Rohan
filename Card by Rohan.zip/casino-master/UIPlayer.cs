using System;

public class UIPlayer : Player {
	public override void makeMove (GameData game)
	{
		throw new System.NotImplementedException ();
	}
}
