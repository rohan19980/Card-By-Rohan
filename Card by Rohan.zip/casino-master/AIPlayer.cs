using System;

public class AIPlayer : Player {
	public override void makeMove (GameData game)
	{
		throw new System.NotImplementedException ();
	}
}
